create definer = root@`%` event cleanup_expired_sessions on schedule
    every '1' HOUR
        starts '2025-10-16 09:42:32'
    enable
    do
    CALL CleanExpiredSessions();

