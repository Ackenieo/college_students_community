create definer = root@`%` event cleanup_old_logs on schedule
    every '1' DAY
        starts '2024-01-01 02:00:00'
    enable
    do
    DELETE FROM system_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

