create
    definer = root@`%` procedure CleanExpiredVerificationCodes()
BEGIN
    DELETE FROM verification_codes
    WHERE expires_at < NOW() OR is_used = TRUE;

    SELECT ROW_COUNT() as cleaned_codes;
END;

