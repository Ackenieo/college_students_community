create definer = root@`%` event cleanup_expired_verification_codes on schedule
    every '1' HOUR
        starts '2025-10-16 09:42:33'
    enable
    do
    CALL CleanExpiredVerificationCodes();

