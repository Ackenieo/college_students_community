create definer = root@`%` view content_review_stats as
select cast(`college_students`.`content_reviews`.`created_at` as date) AS `review_date`,
       `college_students`.`content_reviews`.`content_type`             AS `content_type`,
       `college_students`.`content_reviews`.`review_result`            AS `review_result`,
       count(0)                                                        AS `count`,
       avg(`college_students`.`content_reviews`.`processing_time_ms`)  AS `avg_processing_time`,
       avg(`college_students`.`content_reviews`.`confidence_score`)    AS `avg_confidence_score`
from `college_students`.`content_reviews`
group by cast(`college_students`.`content_reviews`.`created_at` as date),
         `college_students`.`content_reviews`.`content_type`, `college_students`.`content_reviews`.`review_result`
order by `review_date` desc, `college_students`.`content_reviews`.`content_type`,
         `college_students`.`content_reviews`.`review_result`;

-- comment on column content_review_stats.content_type not supported: 内容类型

-- comment on column content_review_stats.review_result not supported: 审核结果

