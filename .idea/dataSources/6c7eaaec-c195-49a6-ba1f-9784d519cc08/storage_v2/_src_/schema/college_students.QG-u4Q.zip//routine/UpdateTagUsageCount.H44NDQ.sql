create
    definer = root@`%` procedure UpdateTagUsageCount(IN tag_name varchar(30))
BEGIN
    UPDATE tags
    SET use_count = use_count + 1, updated_at = NOW()
    WHERE name = tag_name;

    SELECT ROW_COUNT() as updated_tags;
END;

