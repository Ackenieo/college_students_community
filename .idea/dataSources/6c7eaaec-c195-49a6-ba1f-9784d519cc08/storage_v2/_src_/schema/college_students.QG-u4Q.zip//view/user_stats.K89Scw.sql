create definer = root@`%` view user_stats as
select `u`.`id`                             AS `id`,
       `u`.`username`                       AS `username`,
       `u`.`email`                          AS `email`,
       `u`.`full_name`                      AS `full_name`,
       `u`.`status`                         AS `status`,
       `u`.`created_at`                     AS `created_at`,
       `u`.`last_login`                     AS `last_login`,
       count(distinct `uf1`.`follower_id`)  AS `followers_count`,
       count(distinct `uf2`.`following_id`) AS `following_count`,
       count(distinct `us`.`id`)            AS `active_sessions`
from (((`college_students`.`users` `u` left join `college_students`.`user_follows` `uf1`
        on ((`u`.`id` = `uf1`.`following_id`))) left join `college_students`.`user_follows` `uf2`
       on ((`u`.`id` = `uf2`.`follower_id`))) left join `college_students`.`user_sessions` `us`
      on (((`u`.`id` = `us`.`user_id`) and (`us`.`is_active` = true))))
group by `u`.`id`, `u`.`username`, `u`.`email`, `u`.`full_name`, `u`.`status`, `u`.`created_at`, `u`.`last_login`;

-- comment on column user_stats.id not supported: 用户ID

-- comment on column user_stats.username not supported: 用户名

-- comment on column user_stats.email not supported: 邮箱

-- comment on column user_stats.full_name not supported: 真实姓名

-- comment on column user_stats.status not supported: 用户状态

-- comment on column user_stats.created_at not supported: 创建时间

-- comment on column user_stats.last_login not supported: 最后登录时间

