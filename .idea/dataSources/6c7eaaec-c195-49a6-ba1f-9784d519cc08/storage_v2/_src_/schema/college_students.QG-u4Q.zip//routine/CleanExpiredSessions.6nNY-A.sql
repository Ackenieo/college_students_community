create
    definer = root@`%` procedure CleanExpiredSessions()
BEGIN
    DELETE FROM user_sessions
    WHERE expires_at < NOW() OR is_active = FALSE;

    SELECT ROW_COUNT() as cleaned_sessions;
END;

